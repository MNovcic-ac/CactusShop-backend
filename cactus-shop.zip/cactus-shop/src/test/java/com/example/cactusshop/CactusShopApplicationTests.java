package com.example.cactusshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CactusShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
