package com.example.cactusshop.exception;

public class NotLoggedInException extends RuntimeException {

    public NotLoggedInException() {
        super();
    }
}
