package com.example.cactusshop.dto.supplier;

import lombok.Data;

@Data
public class SupplierResponseDto {

    private String supplierName;

    private String supplierContactPhone;
}
