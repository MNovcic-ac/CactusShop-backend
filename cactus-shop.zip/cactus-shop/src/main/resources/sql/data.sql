insert into roles(uuid, role_name, role_description) values ('bf447708-040e-4149-aec3-1f16cacf44ed', 'basic', 'basic user')
